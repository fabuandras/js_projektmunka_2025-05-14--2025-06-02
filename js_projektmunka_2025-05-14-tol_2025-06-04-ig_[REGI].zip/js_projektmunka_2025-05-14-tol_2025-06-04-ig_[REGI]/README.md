> Oldal címe:
# BarkácsBáró

__

> Feladaton dolgozik:
- Ilyés Borbála
- Fabu András
- Halász Dominika
- Kovács Tímea (Nao)

__

> Feladat leosztása:
- index.html:
  - Fabu András, Ilyés Borbála (alap)
- CSS:
  - Fabu András
- main.js:
  - Ilyés Borbála
- termekLista.js:
  - Kovács Tímea (Nao), Fabu András (módosítás)
- Termek.js:
  - Kovács Tímea (Nao)
- Termekek.js:
  - Kovács Tímea (Nao), Fabu András
- Oldal tartalma:
  - Halász Dominika
- Kosar.js:
  - Kovács Tímea (Nao)
- README.md:
  - Halász Dominika
Adatbekero.js:
- Ilyés Borbála, Fabu András

__

> Rendezés, szűrés:
  - Fabu András

__

> UML (kép):
 
![UML](leiras/UML.png)

__

> Drótvázlat (kép):

![UML](leiras/drotVazlat.png)

__

> Egyebek:
- 0.Domi: UML
- 1.Bori: Nav linkek működjenk
- 2.András: Normálisan jelenjenek meg a termékek(fel ugros gomb jobb alul)
- 3.Nao: Kosárba gomb(kosár oldalon láthato legyen)
- 4.András Domi: kezdolap tartalma(tetejen lapozos kép, cég háttere,napi termek az alján,fel ugros gomb jobb alul)
 - 5.Bori: Űrlapok (vélemeény posztolás a kezdolapon,csilagokkal)
- 6.Nao: Kosárba megjelenés ,vásárlás inditása(át tesz az adatbekérésre ,Megjelnitendo adatok 1 elmhez : kiskép ,név?,ár, +- db törlés gomb )
- 7.-: Szűrések rendezes
- 8.Domi: Readmi frissítések
- +.András: Stílus, mozgó hátterek,háttérszín váltás
